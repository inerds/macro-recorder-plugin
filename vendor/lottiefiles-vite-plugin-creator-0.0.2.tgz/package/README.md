# Vite Plugin for Creator Plugins

A Vite plugin to dynamically load and serve custom plugin scripts during development.

### TODO

- [x] Single bundle support
- [x] Test production build (I think dependant on single bundle support)
- [ ] Use manifest from `@lottiefiles/creator-plugin-types` package
- [ ] Revisit plugin deep linking URL formatting after finalizing
