/**
 * The direction for alignment operations.
 *
 */
declare type AlignDirection =
  | "left"
  | "right"
  | "top"
  | "bottom"
  | "horizontal-center"
  | "vertical-center";

/**
 * Represents an animatable property that can have keyframes or a static value.
 *
 * @remarks
 * When `isAnimated` is false, the property uses `staticValue`.
 * Setting `staticValue` when keyframes exist will not affect the animation
 *
 * @example
 * ```ts
 * // Set static value
 * layer.position.staticValue = { x: 100, y: 200 };
 *
 * // Add keyframes for animation
 * layer.position.addKeyframes([
 *   { frame: 0, value: { x: 0, y: 0 } },
 *   { frame: 30, value: { x: 100, y: 200 } }
 * ]);
 * ```
 *
 * @typeParam T - The type of value being animated
 *
 */
declare interface Animatable<T> {
  /**
   * Whether this property has any keyframes
   */
  readonly isAnimated: boolean;
  /**
   * Array of all keyframes for this property
   */
  readonly keyframes: ReadonlyArray<Keyframe<T>>;
  /**
   * The static value used when the property is not animated
   */
  staticValue: T;
  /**
   * Gets the keyframe at a specific frame number, if one exists.
   *
   * @example
   * ```ts
   * // Get keyframe at frame 30
   * const keyframe = layer.position.getKeyframeAt(30);
   * if (keyframe) {
   *   console.log('Keyframe value:', keyframe.value);
   * }
   * ```
   *
   * @param frameNo - The frame number to query
   * @returns The keyframe at that frame, or undefined if none exists
   */
  getKeyframeAt(frameNo: number): Keyframe<T> | undefined;
  /**
   * Adds one or more keyframes to this property.
   *
   * @example
   * ```ts
   * // Add keyframes to layer position
   * layer.position.addKeyframes([
   *   { frame: 0, value: { x: 0, y: 0 } },
   *   { frame: 30, value: { x: 100, y: 200 } }
   * ]);
   * ```
   *
   * @param keyframes - Array of keyframes to add
   */
  addKeyframes(keyframes: Array<KeyframeAdd<T>>): void;
}

/**
 * API version number.
 *
 */
declare type APIVersion = "1";

/**
 * Base interface for all scene graph nodes.
 *
 */
declare interface BaseNodeMixin {
  /**
   * The unique identifier for this node
   */
  readonly id: string;
  /**
   * Plugin data associated with this node
   */
  data: PluginData;
  /**
   * The display name of the node
   *
   * @example
   * ```ts
   * // Update the name of a node
   * node.name = 'New node name';
   * ```
   */
  name: string;
  /**
   * Removes this node from its parent
   *
   * @example
   * ```ts
   * node.remove();
   * ```
   */
  remove(): void;
  /**
   * Creates a duplicate of this node
   *
   * @example
   * ```ts
   * const duplicate = await node.clone();
   * ```
   *
   * @returns A promise that resolves to a copy of this node
   */
  clone(): this;
}

/**
 * Blend modes for layers and groups.
 *
 */
declare type BlendMode =
  | "normal"
  | "multiply"
  | "screen"
  | "overlay"
  | "darken"
  | "lighten"
  | "color-dodge"
  | "color-burn"
  | "hard-light"
  | "soft-light"
  | "difference"
  | "exclusion"
  | "hue"
  | "saturation"
  | "color"
  | "luminosity";

/**
 * Browser storage for plugin data that persists across sessions.
 *
 * @remarks
 * - Client storage allows you to store data on the user's browser. Unlike {@link PluginData}, data stored
 * here is **not** saved with the animation file - it's local to the user's browser only.
 * - Store values like booleans, numbers, strings, dates, objects, arrays, regexps, undefined, or null.
 * - The total amount of data you can save per plugin is limited to 5 MB.
 * - This data is specific to your plugin ID. It will be inaccessible if your plugin ID changes.
 * - Other plugins cannot access this data. However, you should avoid storing sensitive data here. It is possible for users to inspect this data through browser developer tools.
 * - As this data is stored on the user's browser, it might be cleared if the user clears their browser data.
 *
 * @example
 * Store and retrieve user preferences:
 * ```ts
 * await creator.clientStorage.set("theme", "dark");
 *
 * // Retrieve preferences
 * const theme = await creator.clientStorage.get("theme"); // "dark"
 * ```
 *
 */
declare interface ClientStorage {
  /**
   * Retrieves a value from client storage.
   *
   * @param key - The storage key to retrieve
   * @returns A promise that resolves to the stored value, or undefined if not found
   */
  get(key: string): Promise<unknown | undefined>;
  /**
   * Stores a value in client storage.
   *
   * @remarks Will throw an error if storing this value would exceed the plugin's storage quota
   *
   * @example
   * ```ts
   *   await creator.clientStorage.set("theme", "dark");
   * ```
   *
   * @param key - The storage key
   * @param value - The value to store. Can be booleans, numbers, strings, dates, objects, arrays, regexps, undefined, or null.
   * @returns A promise that resolves when the value is stored
   */
  set(key: string, value: unknown): Promise<void>;
  /**
   * Deletes a value from client storage.
   *
   * @example
   * ```ts
   * await creator.clientStorage.delete("theme");
   * ```
   *
   * @param key - The storage key to delete
   * @returns A promise that resolves when the value is deleted
   */
  delete(key: string): Promise<void>;
  /**
   * Gets all storage keys for this plugin.
   *
   * @example
   * ```ts
   * const keys = await creator.clientStorage.keys();
   * ```
   *
   * @returns A promise that resolves to an array of all keys
   */
  keys(): Promise<string[]>;
  /**
   * Clears all client storage data for this plugin.
   *
   * @remarks
   * This removes ALL keys and values stored by your plugin. This operation cannot be undone.
   *
   * @example
   * ```ts
   * await creator.clientStorage.clear();
   * ```
   *
   * @returns A promise that resolves when all data is cleared
   */
  clear(): Promise<void>;
  /**
   * Gets the current data quota usage (in bytes) for this plugin.
   *
   * @example
   * ```ts
   * const usedBytes = await creator.clientStorage.usedQuota();
   * ```
   *
   * @returns A promise that resolves to the number of bytes used
   */
  usedQuota(): Promise<number>;
}

/**
 * Represents an RGB color value.
 *
 * @remarks
 * Color values are in the range [0, 255] for each channel.
 *
 * @example
 * ```ts
 * const red: Color = { r: 255, g: 0, b: 0 };
 * const white: Color = { r: 255, g: 255, b: 255 };
 * const black: Color = { r: 0, g: 0, b: 0 };
 * ```
 *
 */
declare interface Color {
  /**
   * Red channel value (0 to 255)
   */
  r: number;
  /**
   * Green channel value (0 to 255)
   */
  g: number;
  /**
   * Blue channel value (0 to 255)
   */
  b: number;
}

/**
 * Represents an array of color stops for gradients.
 *
 * @example
 * ```ts
 * // Red to blue gradient
 * const gradientStops: ColorStops = [
 *   { color: { r: 255, g: 0, b: 0 }, offset: 0, opacity: 1 },
 *   { color: { r: 0, g: 0, b: 255 }, offset: 1, opacity: 1 }
 * ];
 * ```
 *
 */
declare type ColorStops = ReadonlyArray<{
  /**
   * The color at this stop
   */
  readonly color: Color;
  /**
   * The position of this stop along the gradient (0 to 1)
   */
  readonly offset: number;
  /**
   * The opacity at this stop (0 to 1)
   */
  readonly opacity: number;
}>;

/**
 * Console API for plugin logging.
 *
 * @remarks
 * Similar to the browser console API but works within the plugin sandbox environment.
 *
 */
declare interface ConsoleAPI {
  /**
   * Logs a message
   */
  log: (...args: unknown[]) => void;
  /**
   * Logs a warning message
   */
  warn: (...args: unknown[]) => void;
  /**
   * Logs an error message
   */
  error: (...args: unknown[]) => void;
  /**
   * Logs an info message
   */
  info: (...args: unknown[]) => void;
  /**
   * Logs a debug message
   */
  debug: (...args: unknown[]) => void;
}

/**
 * A container is a node that can contain shapes.
 *
 * @remarks
 * Containers are the primary layer type for vector graphics in Creator. They hold shapes,
 * fills, and strokes, and provide transform properties that affect all contained shapes.
 *
 */
declare interface Container extends LayerMixin, ShapeContainerMixin {
  /**
   * Layer type
   */
  readonly type: "CONTAINER";
}

/**
 * Represents the easing function for a keyframe.
 *
 * @remarks
 * This controls how the animation interpolates into or out of this keyframe. Updating the easing values of a keyframe can make the animation feel smoother or more natural.
 *
 * @example
 * ```ts
 * // setting an ease-in-out easing from `keyframeA` to `keyframeB`
 * keyframeA.easing.out = { x: 0.42, y: 0 };
 * keyframeB.easing.in = { x: 0.58, y: 1 };
 * ```
 *
 */
declare interface Easing {
  /**
   * Incoming tangent control point. This updates the cubic bezier curve interpolation from the previous keyframe to this one.
   *
   * @remarks
   * Note: Setting this on the first keyframe of an {@link Animatable} has no effect.
   */
  in?: Vector | undefined;
  /**
   * Outgoing tangent control point. This updates the cubic bezier curve interpolation from this keyframe to the next one.
   */
  out?: Vector | undefined;
}

/**
 * Represents an ellipse shape.
 *
 */
declare interface Ellipse extends ShapeMixin {
  /**
   * Shape type
   */
  readonly type: "ELLIPSE";
  /**
   * Size of the ellipse
   */
  readonly size: Animatable<Size>;
  /**
   * Position of the ellipse
   */
  readonly position: Animatable<Vector>;
}

/**
 * Options for creating an ellipse shape.
 *
 */
declare interface EllipseOptions {
  /**
   * Initial position of the ellipse
   */
  position?: Vector;
  /**
   * Initial size of the ellipse
   */
  size?: Size;
}

/**
 * The direction for flip operations.
 *
 */
declare type FlipDirection = "horizontal" | "vertical";

/**
 * Base interface for gradient paints.
 *
 */
declare interface GradientPaint {
  /**
   * The start point of the gradient
   */
  readonly start: Animatable<Vector>;
  /**
   * The end point of the gradient
   */
  readonly end: Animatable<Vector>;
  /**
   * Array of color stops defining the gradient
   */
  readonly stops: Animatable<ColorStops>;
}

/**
 * Represents a group of shapes
 *
 */
declare interface Group
  extends BaseNodeMixin,
    TransformMixin,
    ShapeContainerMixin {
  /**
   * Shape type
   */
  readonly type: "GROUP";
  /**
   * The parent container of this group
   */
  readonly parent: Parent<Group>;
  /**
   * Opacity of this group (0 to 100)
   */
  readonly opacity: Animatable<number>;
  /**
   * Blend mode for this group
   */
  blendMode: BlendMode;
  /**
   * Aligns this group within its parent
   *
   * @param type - The alignment direction
   */
  align(type: AlignDirection): void;
}

/**
 * Options for importing animations into a scene.
 *
 */
declare interface ImportOptions {
  /**
   * The animation to import.
   * Accepts the following types:
   * - URL to a Lottie JSON file
   * - URL to a dotLottie file
   * - URL to an SVG file
   * - A Lottie JSON string
   * - An SVG string
   */
  animation: string;
}

/**
 * Represents a keyframe in the animation timeline.
 *
 * @example
 * ```ts
 * // updating the position keyframe at frame 30
 * const positionKeyframe = layer.position.getKeyframeAt(30);
 * if (positionKeyframe) {
 *   positionKeyframe.value = { x: 100, y: 200 };
 *   positionKeyframe.outTangent = { x: 0.65, y: 0 };
 *   positionKeyframe.inTangent = { x: 0.36, y: 1 };
 * }
 * ```
 *
 * @typeParam T - The type of value being animated
 *
 */
declare interface Keyframe<T> {
  /**
   * Unique identifier for this keyframe
   */
  readonly id: string;
  /**
   * The frame number of this keyframe
   */
  frame: number;
  /**
   * The value of this keyframe
   */
  value: T;
  /**
   * Easing function for this keyframe
   */
  easing: Easing;
  /**
   * Removes this keyframe from its parent property
   *
   * @example
   * ```ts
   * keyframe.remove();
   * ```
   */
  remove(): void;
}

/**
 * Keyframe data used for creating new keyframes
 *
 * @typeParam T - The type of value being animated
 *
 */
declare type KeyframeAdd<T> = Omit<Keyframe<T>, "id" | "remove" | "easing"> &
  Partial<Pick<Keyframe<T>, "easing">>;

/**
 * Union type of all layer types.
 *
 */
declare type Layer = Container | SceneInstance;

/**
 * Mixin providing common layer properties and methods.
 *
 * @remarks
 * Layers are timeline-based objects that exist within a specific frame range defined by
 * `startFrame` and `endFrame`. They can contain shapes and have animatable transform properties.
 * Unlike shapes, layers have their own timeline that can be offset independently from their parent scene.
 *
 */
declare interface LayerMixin extends BaseNodeMixin, TransformMixin {
  /**
   * The parent of this layer
   */
  readonly parent?: Parent<Layer> | undefined;
  /**
   * Opacity of this layer (0 to 100)
   */
  readonly opacity: Animatable<number>;
  /**
   * Whether the layer is visible
   */
  visible: boolean;
  /**
   * Whether the layer is locked (prevents the user from editing it)
   */
  locked: boolean;
  /**
   * Whether the layer is focused
   */
  focused: boolean;
  /**
   * The frame number at which the layer starts being visible
   */
  startFrame: number;
  /**
   * The frame number at which the layer stops being visible
   */
  endFrame: number;
  /**
   * The offset for the layer's timeline in frames
   */
  timelineOffset: number;
  /**
   * The blend mode of this layer
   *
   * @example
   * ```ts
   * // Set the blend mode to multiply
   * layer.blendMode = 'multiply';
   * ```
   */
  blendMode: BlendMode;
  /**
   * Whether this layer acts as a matte for another layer
   */
  isMatte: boolean;
  /**
   * The matte applied onto this layer, if any
   *
   * @example
   * ```ts
   * // Create a matte
   * const matte: Matte = {
   *   layer: matteSource,
   *   inverted: false
   * };
   *
   * // Apply matte to layer
   * layer.matte = matte;
   * ```
   */
  matte?: Matte | undefined;
  /**
   * An array of masks applied to this layer
   */
  readonly masks: ReadonlyArray<Mask>;
  /**
   * Adds a mask to this layer
   *
   * @example
   * ```ts
   * // Create a rectangular mask path
   * const maskPath: PathData = {
   *   points: [
   *     { vertex: { x: 0, y: 0 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *     { vertex: { x: 100, y: 0 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *     { vertex: { x: 100, y: 100 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *     { vertex: { x: 0, y: 100 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } }
   *   ],
   *   closed: true
   * };
   *
   * // Add mask to layer
   * layer.addMask({
   *   mode: 'add',
   *   pathData: maskPath,
   *   opacity: 100
   * });
   * ```
   *
   * @param mask - The mask to add
   */
  addMask(mask: WithStaticProps<Mask>): void;
  /**
   * Removes a mask by its index
   *
   * @example
   * ```ts
   * // Remove the first mask applied to the layer
   * layer.removeMask(0);
   * ```
   *
   * @param index - The index of the mask to remove
   */
  removeMask(index: number): void;
  /**
   * Aligns this layer within its parent
   *
   * @example
   * ```ts
   * // Align layer to the left of its parent
   * layer.align('left');
   * ```
   *
   * @param type - The alignment direction
   */
  align(type: AlignDirection): void;
  /**
   * Flips this layer horizontally or vertically
   *
   * @example
   * ```ts
   * // Flip layer horizontally
   * layer.flip('horizontal');
   * ```
   *
   * @param type - The flip direction
   */
  flip(type: FlipDirection): void;
}

/**
 * Represents a linear gradient paint.
 *
 * @example
 * ```ts
 * // Add a linear gradient from left to right
 * container.addFill({
 *   type: 'GRADIENT_LINEAR',
 *   start: { x: 0, y: 100 },
 *   end: { x: 200, y: 100 },
 *   stops: [
 *     { color: { r: 255, g: 0, b: 0 }, offset: 0, opacity: 1 },
 *     { color: { r: 0, g: 0, b: 255 }, offset: 1, opacity: 1 }
 *   ]
 * });
 * ```
 *
 */
declare interface LinearGradientPaint extends GradientPaint {
  /**
   * Paint type
   */
  readonly type: "GRADIENT_LINEAR";
}

/**
 * Represents a mask applied to a layer.
 *
 */
declare interface Mask {
  /**
   * Whether the mask adds or subtracts from visibility
   */
  readonly mode: MaskMode;
  /**
   * The path data defining the mask shape
   */
  readonly pathData: Animatable<PathData>;
  /**
   * The opacity of the mask effect (0 to 100)
   */
  readonly opacity: Animatable<number>;
}

/**
 * Mode for mask operations.
 *
 */
declare type MaskMode = "add" | "subtract";

/**
 * Represents a transformation matrix.
 *
 */
declare interface Matrix {
  readonly a: number;
  readonly b: number;
  readonly c: number;
  readonly d: number;
  readonly e: number;
  readonly f: number;
}

/**
 * Represents a matte effect that is applied onto another layer.
 *
 */
declare interface Matte {
  /**
   * The layer used as the matte source
   */
  readonly layer: Layer;
  /**
   * Whether to invert the matte effect
   */
  readonly inverted: boolean;
}

/**
 * Options for moving a node in the hierarchy.
 *
 */
declare type MoveOptions<T = Layer | Shape> =
  | {
      to: Parent<T>;
    }
  | {
      before: Sibling<T>;
    }
  | {
      after: Sibling<T>;
    };

/**
 * Union type of all paint types.
 *
 */
declare type Paint = SolidPaint | LinearGradientPaint | RadialGradientPaint;

/**
 * Type helper to get valid parent types for a node.
 *
 */
declare type Parent<T> = T extends Layer
  ? Layer | Scene
  : T extends Group
    ? Container | Group
    : T extends Shape
      ? Container | Group
      : never;

/**
 * Represents a custom bezier path shape.
 *
 */
declare interface Path extends ShapeMixin {
  /**
   * Shape type
   */
  readonly type: "PATH";
  /**
   * The bezier path data defining this shape
   */
  readonly pathData: Animatable<PathData>;
}

/**
 * Represents a bezier path composed of multiple points.
 *
 * @remarks
 * PathData defines a vector shape path that can be either open or closed.
 * When `closed` is true, the path automatically connects the last point back to the first.
 * Paths require at least 2 points for a line.
 *
 * @example
 * ```ts
 * const trianglePath: PathData = {
 *   points: [
 *     { vertex: { x: 0, y: 0 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
 *     { vertex: { x: 100, y: 0 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
 *     { vertex: { x: 50, y: 100 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } }
 *   ],
 *   closed: true
 * };
 * ```
 *
 */
declare interface PathData {
  /**
   * Array of path points defining the bezier curve
   */
  readonly points: PathPoint[];
  /**
   * Whether the path is closed (connects last point to first)
   */
  readonly closed: boolean;
}

/**
 * Options for creating a path shape.
 *
 */
declare interface PathOptions {
  /**
   * Initial path points
   */
  points?: PathPoint[];
  /**
   * Whether the path should be closed
   */
  closed?: boolean;
}

/**
 * Represents a point on a bezier path.
 *
 * @remarks
 *
 */
declare interface PathPoint {
  /**
   * The position of the point
   */
  readonly vertex: Vector;
  /**
   * The incoming tangent
   */
  readonly inTan: Vector;
  /**
   * The outgoing tangent
   */
  readonly outTan: Vector;
}

/**
 * Main plugin API interface.
 *
 * @remarks
 * This is the primary interface for interacting with LottieFiles Creator from a plugin.
 * Access it via the global `creator` object.
 *
 */
declare interface PluginAPI {
  /**
   * The API version being used
   */
  readonly apiVersion: APIVersion;
  /**
   * The currently active scene
   */
  readonly activeScene: Scene;
  /**
   * Browser storage for plugin data.
   */
  readonly clientStorage: ClientStorage;
  /**
   * Array of all scenes in the animation
   */
  readonly scenes: ReadonlyArray<Scene>;
  /**
   * API for managing the plugin UI
   */
  readonly ui: UIAPI;
  /**
   * API for timeline playback control
   */
  readonly timeline: TimelineAPI;
  /**
   * API for accessing the currently selected nodes and keyframes
   */
  readonly selection: SelectionAPI;
  /**
   * Switches to a different scene
   *
   * @example
   * ```ts
   * creator.switchToScene(scene2);
   * ```
   *
   * @param scene - The scene to switch to
   */
  switchToScene: (scene: Scene) => void;
  /**
   * Closes the plugin and stops it from running
   *
   * @example
   * ```ts
   * creator.closePlugin();
   * ```
   */
  closePlugin: () => void;
  /**
   * Registers an event listener for plugin events
   *
   * @example
   * ```ts
   * creator.on('selection:nodes', callback);
   * ```
   *
   * @param type - The event type to listen for
   * @param callback - Function called when the event fires
   * @typeParam T - The event name type
   */
  on<T extends PluginEventName>(
    type: T,
    callback: (data: PluginEventData<T>) => void
  ): void;
  /**
   * Removes an event listener
   *
   * @example
   * ```ts
   * creator.off('selection:nodes', callback);
   * ```
   *
   * @param type - The event type to stop listening for
   * @param callback - The callback function to remove
   * @typeParam T - The event name type
   */
  off<T extends PluginEventName>(
    type: T,
    callback: (data: PluginEventData<T>) => void
  ): void;
}

/**
 * Custom data on this node associated with the current plugin
 *
 * @remarks
 * - This lets you store custom data on any node that is specific to your plugin.
 * - This data is saved within Creator's animation file, but will not be retained when exported to an animation.
 * - The total amount of data (i.e. all key-value pairs) you can save per node is limited to 5 kB.
 * - This data is specific to your plugin ID. It will be inaccessible if your plugin ID changes.
 * - Other plugins cannot access this data. However, you should avoid storing sensitive data here. This data is stored in Creator's saved animation file. It will not prevent users from accessing it if they inspect and attempt to decode the file.
 *
 */
declare interface PluginData {
  /**
   * Clears all data associated with the current plugin
   *
   * @example
   * ```ts
   * node.data.clear();
   * ```
   */
  clear(): void;
  /**
   * Deletes the value for a specific key
   *
   * @example
   * ```ts
   * node.data.delete("storedColors");
   * ```
   *
   * @param key - The key to delete
   */
  delete(key: string): void;
  /**
   * Gets the value for a specific key
   *
   * @example
   * ```ts
   * node.data.get("storedColors");
   * ```
   *
   * @param key - The key to get
   * @returns The value associated with the key, or undefined if not found
   */
  get(key: string): string | undefined;
  /**
   * List of all keys stored for the current plugin
   *
   * @example
   * ```ts
   * const keys = node.data.keys;
   * ```
   *
   * @returns Array of keys
   */
  readonly keys: ReadonlyArray<string>;
  /**
   * Sets the value for a specific key
   *
   * @remarks Will throw an error if setting this key-value pair would exceed the plugin's data quota for this node
   *
   * @example
   * ```ts
   * // setting a string value
   * node.data.set("storedColors", "#FF0000");
   *
   * // setting a non-string value
   * const colors = ["#FF0000", "#00FF00", "#0000FF"];
   * node.data.set("storedColors", JSON.stringify(colors));
   *
   * // getting the stringified value back
   * const storedColors = JSON.parse(node.data.get("storedColors"));
   * ```
   *
   * @param key - The key to set
   * @param value - The value to set. If you want to set non-string values, you can serialize them to a string (e.g. using JSON.stringify) before storing.
   */
  set(key: string, value: string): void;
  /**
   * The total amount of data (in bytes) currently used by this plugin on this node
   *
   * @example
   * ```ts
   * const usedBytes = node.data.usedQuota;
   * ```
   */
  usedQuota: number;
}

/**
 * Event types that plugins can listen to.
 *
 */
declare type PluginEvent =
  | {
      /**
       * Generic message event
       */
      type: "message";
      /**
       * Message data
       */
      data: unknown;
    }
  | {
      /**
       * Event fired when the node selection changes
       */
      type: "selection:nodes";
      /**
       * Selected nodes
       */
      data: (Layer | Shape)[];
    }
  | {
      /**
       * Event fired when the keyframe selection changes
       */
      type: "selection:keyframes";
      /**
       * Selected keyframes
       */
      data: Keyframe<unknown>[];
    };

/**
 * Helper type to extract event data for a specific event name.
 *
 * @typeParam T - The event name
 *
 */
declare type PluginEventData<T extends PluginEventName> =
  Extract<
    PluginEvent,
    {
      type: T;
    }
  > extends {
    data: infer D;
  }
    ? D
    : undefined;

/**
 * Union of all plugin event types.
 *
 */
declare type PluginEventName = PluginEvent["type"];

/**
 * Global objects available in the plugin environment.
 *
 */
declare interface PluginGlobal {
  /**
   * Console API for logging
   */
  readonly console: ConsoleAPI;
  /**
   * Main Creator plugin API
   */
  readonly creator: PluginAPI;
}

/**
 * Represents a polygon shape.
 *
 */
declare interface Polygon extends ShapeMixin {
  /**
   * Shape type
   */
  readonly type: "POLYGON";
  /**
   * Number of points of the polygon
   */
  readonly points: Animatable<number>;
  /**
   * Position of the polygon
   */
  readonly position: Animatable<Vector>;
  /**
   * Rotation angle in degrees
   */
  readonly rotation: Animatable<number>;
  /**
   * Outer radius of the polygon
   */
  readonly outerRadius: Animatable<number>;
  /**
   * Roundness of the outer points (0-100)
   */
  readonly outerRoundness: Animatable<number>;
}

/**
 * Options for creating a polygon shape.
 *
 */
declare interface PolygonOptions {
  /**
   * Initial position of the polygon
   */
  position?: Vector;
  /**
   * Initial rotation angle in degrees
   */
  rotation?: number;
  /**
   * Number of points/sides of the polygon
   */
  points?: number;
  /**
   * Initial inner radius
   */
  innerRadius?: number;
  /**
   * Initial outer radius
   */
  outerRadius?: number;
  /**
   * Initial roundness of inner points (0-100)
   */
  innerRoundness?: number;
  /**
   * Initial roundness of outer points (0-100)
   */
  outerRoundness?: number;
}

/**
 * Represents a radial gradient paint.
 *
 * @example
 * ```ts
 * // Add a radial gradient
 * container.addFill({
 *   type: 'GRADIENT_RADIAL',
 *   start: { x: 100, y: 100 },  // Center
 *   end: { x: 200, y: 100 },     // Radius endpoint
 *   highlightAngle: 45,           // Rotate highlight 45 degrees
 *   highlightLength: 50,          // Move highlight 50% toward edge
 *   stops: [
 *     { color: { r: 255, g: 255, b: 255 }, offset: 0, opacity: 1 },
 *     { color: { r: 0, g: 0, b: 0 }, offset: 1, opacity: 1 }
 *   ]
 * });
 * ```
 *
 */
declare interface RadialGradientPaint extends GradientPaint {
  /**
   * Paint type
   */
  readonly type: "GRADIENT_RADIAL";
  /**
   * The angle of the highlight/focal point
   */
  readonly highlightAngle: Animatable<number>;
  /**
   * The length of the highlight/focal point from the center (-100 to 100)
   */
  readonly highlightLength: Animatable<number>;
}

/**
 * Represents a rectangle shape.
 *
 */
declare interface Rectangle extends ShapeMixin {
  /**
   * Shape type
   */
  readonly type: "RECTANGLE";
  /**
   * Size of the rectangle
   */
  readonly size: Animatable<Size>;
  /**
   * Position of the rectangle
   */
  readonly position: Animatable<Vector>;
  /**
   * Corner roundness (0 = sharp corners)
   */
  readonly roundness: Animatable<number>;
}

/**
 * Options for creating a rectangle shape.
 *
 */
declare interface RectangleOptions {
  /**
   * Initial position of the rectangle
   */
  position?: Vector;
  /**
   * Initial size of the rectangle
   */
  size?: Size;
  /**
   * Initial corner roundness (0 = sharp corners)
   */
  roundness?: number;
}

/**
 * Represents a scene in the animation.
 *
 * @remarks
 * A scene represents a container for animation content. It defines
 * dimensions, framerate, duration, and contain layers.
 *
 * @example
 * ```ts
 * const scene = await creator.createScene({
 *   name: 'New Scene',
 *   size: { width: 1920, height: 1080 },
 *   framerate: 60,
 *   duration: 5
 * });
 * ```
 *
 */
declare interface Scene extends BaseNodeMixin {
  /**
   * Scene type
   */
  readonly type: "SCENE";
  /**
   * Dimensions of the scene in pixels
   */
  size: Size;
  /**
   * Background color of the scene
   *
   * @remarks
   * Use the background color to preview the scene in different colors. Note that it is not exported to the final animation.
   *
   * @example
   * ```ts
   * // Set the background color of a scene
   * scene.backgroundColor = { r: 255, g: 0, b: 0 };
   * ```
   */
  backgroundColor: Color;
  /**
   * Frames per second
   */
  framerate: number;
  /**
   * Duration of the scene in seconds
   */
  duration: number;
  /**
   * A single animation can have multiple child scenes.
   * This property indicates whether this is the top-level scene in the animation.
   */
  readonly isMainScene?: boolean;
  /**
   * Array of layers in this scene
   */
  readonly layers: ReadonlyArray<Layer>;
  /**
   * Creates an instance from the specified layers
   *
   * @example
   * ```ts
   * // Create a scene instance from layers
   * const sceneInstance = await scene.createSceneInstance([layer1, layer2]);
   * ```
   *
   * @param layers - Array of layers to instance
   * @returns A promise that resolves to the newly created scene instance layer
   */
  createSceneInstance(layers: ReadonlyArray<Layer>): SceneInstance;
  /**
   * Creates a new container layer with a rectangle shape
   *
   * @example
   * ```ts
   * // Create a container with a rectangle shape
   * const container =  await scene.createRectangleContainer({
   *   position: { x: 100, y: 100 },
   *   shape: {
   *     size: { width: 200, height: 100 },
   *     roundness: 10
   *   }
   * });
   * ```
   *
   * @param opts - Optional configuration for the container and rectangle
   * @returns A promise that resolves to the newly created container with rectangle
   */
  createRectangleContainer(
    opts?: WithContainerOptions<RectangleOptions>
  ): Container;
  /**
   * Creates a new container layer with an ellipse shape
   *
   * @example
   * ```ts
   * // Create a container with an ellipse shape
   * const container = await scene.createEllipseContainer({
   *   shape: {
   *     size: { width: 200, height: 100 }
   *   }
   * });
   * ```
   *
   * @param opts - Optional configuration for the container and ellipse
   * @returns The newly created container with ellipse
   */
  createEllipseContainer(
    opts?: WithContainerOptions<EllipseOptions>
  ): Container;
  /**
   * Creates a new container layer with a polygon shape
   *
   * @example
   * ```ts
   * // Create a container with a polygon shape
   * const container = await scene.createPolygonContainer({
   *   shape: {
   *     points: 5,
   *     innerRadius: 25,
   *     outerRadius: 50
   *   }
   * });
   * ```
   *
   * @param opts - Optional configuration for the container and polygon
   * @returns The newly created container with polygon
   */
  createPolygonContainer(
    opts?: WithContainerOptions<PolygonOptions>
  ): Container;
  /**
   * Creates a new container layer with a star shape
   *
   * @example
   * ```ts
   * // Create a container with a star shape
   * const container = await scene.createStarContainer({
   *   shape: {
   *     points: 5,
   *     innerRadius: 25,
   *     outerRadius: 50
   *   }
   * });
   * ```
   *
   * @param opts - Optional configuration for the container and star
   * @returns The newly created container with star
   */
  createStarContainer(opts?: WithContainerOptions<StarOptions>): Container;
  /**
   * Creates a new container layer with a path shape
   *
   * @example
   * ```ts
   * // Create a container with a path shape
   * const container = await scene.createPathContainer({
   *   shape: {
   *     points: [
   *       { vertex: { x: 0, y: 0 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *       { vertex: { x: 100, y: 100 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *     ],
   *     closed: true
   *   }
   * });
   * ```
   *
   * @param opts - Optional configuration for the container and path
   * @returns A promise that resolves to the newly created container with path
   */
  createPathContainer(opts?: WithContainerOptions<PathOptions>): Container;
  /**
   *
   * @param options - Options for importing the animation
   * @returns The imported scene instance
   */
  import(options: ImportOptions): Promise<SceneInstance>;
}

/**
 * Options for creating a new scene.
 *
 */
declare type SceneCreateOptions = Partial<
  Pick<Scene, "name" | "size" | "backgroundColor" | "framerate" | "duration">
>;

/**
 * Represents an instance of a scene.
 *
 * @remarks
 * A scene instance is a type of layer that references a source scene.
 * Changes to the source scene automatically reflect in all instances.
 *
 */
declare interface SceneInstance extends LayerMixin {
  /**
   * Layer type
   */
  readonly type: "SCENE_INSTANCE";
  /**
   * The scene being instanced
   */
  readonly scene: Scene;
  /**
   * Breaks the connection to the source scene, converting this to a regular container
   */
  break(): void;
}

/**
 * API for accessing the currently selected nodes and keyframes.
 *
 */
declare interface SelectionAPI {
  /**
   * Currently selected layers and shapes
   *
   * @example
   * ```ts
   * const selectedNodes = creator.selection.nodes;
   * ```
   */
  nodes: ReadonlyArray<Layer | Shape>;
  /**
   * Currently selected keyframes
   *
   * @example
   * ```ts
   * const selectedKeyframes = creator.selection.keyframes;
   * ```
   */
  keyframes: ReadonlyArray<Keyframe<unknown>>;
}

/**
 * Union type of all shape types.
 *
 */
declare type Shape = Group | Rectangle | Ellipse | Polygon | Star | Path;

/**
 * Mixin for nodes that can contain shapes and have styling properties.
 *
 */
declare interface ShapeContainerMixin {
  /**
   * Child shapes contained in this container
   */
  readonly shapes: ReadonlyArray<Shape>;
  /**
   * Fill paints applied to shapes in this container
   */
  readonly fills: ReadonlyArray<Paint>;
  /**
   * Strokes applied to shapes in this container
   */
  readonly strokes: ReadonlyArray<Stroke>;
  /**
   * Adds a fill paint to this container
   *
   * @example
   * ```ts
   * // Add a solid red paint to container
   * container.addFill({
   *   type: 'SOLID',
   *   color: { r: 255, g: 0, b: 0 }
   * });
   * ```
   *
   * @param paint - The paint to add
   */
  addFill(paint: WithStaticProps<Paint>): void;
  /**
   * Removes a fill by its index
   *
   * @example
   * ```ts
   * // Remove the first fill from container
   * container.removeFill(0);
   * ```
   *
   * @param index - The index of the fill to remove
   */
  removeFill(index: number): void;
  /**
   * Adds a stroke to this container
   *
   * @example
   * ```ts
   * // Add a solid black stroke to container
   * container.addStroke({
   *   fill: { type: 'SOLID', color: { r: 0, g: 0, b: 0 } },
   *   width: 2
   * });
   * ```
   *
   * @param stroke - The stroke to add
   */
  addStroke(stroke: WithStaticProps<Stroke>): void;
  /**
   * Removes a stroke by its index
   *
   * @example
   * ```ts
   * // Remove the first stroke from container
   * container.removeStroke(0);
   * ```
   *
   * @param index - The index of the stroke to remove
   */
  removeStroke(index: number): void;
  /**
   * Creates a new group containing the specified shapes
   *
   * @example
   * ```ts
   * // Create a group containing two shapes
   * const group = await container.createGroup([ellipseShape, rectangleShape]);
   * ```
   *
   * @param nodes - Array of shapes to add to the group
   * @returns The newly created group
   */
  createGroup(nodes: ReadonlyArray<Shape>): Group;
  /**
   * Creates a new rectangle shape in this container
   *
   * @example
   * ```ts
   * // Create a rectangle shape
   * const rectangle = await container.createRectangle({
   *   position: { x: 100, y: 100 },
   *   size: { width: 200, height: 100 },
   *   roundness: 10
   * });
   * ```
   *
   * @param opts - Optional configuration for the rectangle
   * @returns The newly created rectangle
   */
  createRectangle(opts?: RectangleOptions): Rectangle;
  /**
   * Creates a new ellipse shape in this container
   *
   * @example
   * ```ts
   * // Create an ellipse shape
   * const ellipse = await container.createEllipse({
   *   position: { x: 100, y: 100 },
   *   size: { width: 200, height: 100 }
   * });
   * ```
   *
   * @param opts - Optional configuration for the ellipse
   * @returns The newly created ellipse
   */
  createEllipse(opts?: EllipseOptions): Ellipse;
  /**
   * Creates a new polygon shape in this container
   *
   * @example
   * ```ts
   * // Create a polygon shape
   * const polygon = await container.createPolygon({
   *   position: { x: 100, y: 100 },
   *   points: 5,
   *   innerRadius: 25,
   *   outerRadius: 50
   * });
   * ```
   *
   * @param opts - Optional configuration for the polygon
   * @returns The newly created polygon
   */
  createPolygon(opts?: PolygonOptions): Polygon;
  /**
   * Creates a new star shape in this container
   *
   * @example
   * ```ts
   * // Create a star shape
   * const star = await container.createStar({
   *   position: { x: 100, y: 100 },
   *   points: 5,
   *   outerRadius: 50,
   *   innerRadius: 25
   * });
   * ```
   *
   * @param opts - Optional configuration for the star
   * @returns The newly created star
   */
  createStar(opts?: StarOptions): Star;
  /**
   * Creates a new path shape in this container
   *
   * @example
   * ```ts
   * // Create a path shape
   * const path = await container.createPath({
   *   points: [
   *     { vertex: { x: 0, y: 0 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *     { vertex: { x: 100, y: 100 }, inTan: { x: 0, y: 0 }, outTan: { x: 0, y: 0 } },
   *   ],
   *   closed: true
   * });
   * ```
   *
   * @param opts - Optional configuration for the path
   * @returns A promise that resolves to the newly created path
   */
  createPath(opts?: PathOptions): Path;
}

/**
 * A mixin to provide common shape properties and methods.
 *
 */
declare interface ShapeMixin extends BaseNodeMixin {
  /**
   * The parent of this shape
   */
  readonly parent?: Parent<Shape> | undefined;
  /**
   * Converts this shape to path data from a specific frame
   *
   * @remarks
   * Convering this shape to path data means that its shape-specific properties and methods will
   * no longer be available.
   *
   * @param frame - Optional frame number to get the path data from. Defaults to the current frame
   * @returns The path data representation of this shape
   */
  toPathData(frame?: number): PathData;
}

/**
 * Options for configuring the plugin UI display.
 *
 * @example
 * ```ts
 * creator.ui.show({ width: 400, height: 600 });
 * ```
 *
 */
declare interface ShowUIOptions {
  /**
   * Width of the plugin UI window in pixels
   */
  width?: number | undefined;
  /**
   * Height of the plugin UI window in pixels
   */
  height?: number | undefined;
}

/**
 * Type helper to get valid sibling types for a node.
 *
 */
declare type Sibling<T> = T extends Layer
  ? Layer
  : T extends Shape
    ? Shape
    : never;

/**
 * Represents dimensions with width and height.
 *
 * @example
 * ```ts
 * const size: Size = { width: 100, height: 100 };
 * ```
 *
 */
declare interface Size {
  /**
   * Width
   */
  width: number;
  /**
   * Height
   */
  height: number;
}

/**
 * Represents a solid color paint.
 *
 * @example
 * ```ts
 * // Add a solid red paint to container
 * container.addFill({
 *   type: 'SOLID',
 *   color: { r: 255, g: 0, b: 0 }
 * });
 * ```
 *
 */
declare interface SolidPaint {
  /**
   * Paint type
   */
  readonly type: "SOLID";
  /**
   * The animatable color of the paint
   */
  readonly color: Animatable<Color>;
}

/**
 * Represents a star shape.
 *
 */
declare interface Star extends ShapeMixin {
  /**
   * Shape type
   */
  readonly type: "STAR";
  /**
   * Number of points of the star
   */
  readonly points: Animatable<number>;
  /**
   * Position of the star
   */
  readonly position: Animatable<Vector>;
  /**
   * Rotation angle in degrees
   */
  readonly rotation: Animatable<number>;
  /**
   * Inner radius of the star
   */
  readonly innerRadius: Animatable<number>;
  /**
   * Outer radius of the star
   */
  readonly outerRadius: Animatable<number>;
  /**
   * Roundness of the inner points (0-100)
   */
  readonly innerRoundness: Animatable<number>;
  /**
   * Roundness of the outer points (0-100)
   */
  readonly outerRoundness: Animatable<number>;
}

/**
 * Options for creating a star shape.
 *
 */
declare interface StarOptions {
  /**
   * Initial position of the star
   */
  position?: Vector;
  /**
   * Number of points of the star
   */
  points?: number;
  /**
   * Initial outer radius
   */
  outerRadius?: number;
  /**
   * Initial inner radius
   */
  innerRadius?: number;
}

/**
 * Represents a stroke (outline) applied to a shape.
 *
 * @example
 * ```ts
 * // Add 5px solid stroke
 * container.addStroke({
 *   fill: {
 *     type: 'SOLID',
 *     color: { r: 0, g: 0, b: 0 }
 *   },
 *   width: 5
 * });
 * ```
 *
 */
declare interface Stroke {
  /**
   * The fill paint of the stroke
   */
  readonly fill: Paint;
  /**
   * The width of the stroke
   */
  readonly width: Animatable<number>;
}

/**
 * API for controlling the animation timeline.
 *
 */
declare interface TimelineAPI {
  /**
   * The current frame number
   */
  readonly currentFrame: number;
  /**
   * Whether the animation is currently playing
   */
  readonly isPlaying: boolean;
  /**
   * Starts playing the animation
   *
   * @example
   * ```ts
   * creator.timeline.play();
   * ```
   */
  play(): void;
  /**
   * Pauses the animation playback
   *
   * @example
   * ```ts
   * creator.timeline.pause();
   * ```
   */
  pause(): void;
  /**
   * Jumps to a specific frame in the timeline
   *
   * @example
   * ```ts
   * creator.timeline.goToFrame(60);
   * ```
   *
   * @param frame - The frame number to jump to
   */
  goToFrame(frame: number): void;
}

/**
 * Mixin providing common transform properties.
 *
 */
declare interface TransformMixin {
  /**
   * The position of the node
   */
  readonly position: Animatable<Vector>;
  /**
   * The rotation of the node in degrees
   */
  readonly rotation: Animatable<number>;
  /**
   * The scale of the node
   */
  readonly scale: Animatable<Vector>;
  /**
   * The skew of the node in degrees
   */
  readonly skew: Animatable<number>;
  /**
   * Skew axis angle in degrees
   */
  readonly skewAxis: Animatable<number>;
  /**
   * Gets the transformation matrix of the node at a specific frame
   *
   * @example
   * ```ts
   * // Get the transformation matrix at frame 30
   * const matrix = node.getMatrixAtFrame(30);
   * console.log('Transformation matrix:', matrix);
   * ```
   *
   * @param frameNo - The frame number to get the matrix for
   * @returns The transformation matrix of the node at that frame
   */
  getMatrixAtFrame(frameNo: number): Matrix;
}

/**
 * API for managing and communicating with the plugin's user interface.
 *
 * @example
 * ```ts
 * // Send message to UI
 * creator.ui.postMessage({ type: 'update', data: someData });
 *
 * // Listen for messages from UI
 * creator.ui.onMessage((message) => {
 *   console.log('Received from UI:', message);
 * });
 * ```
 *
 */
declare interface UIAPI {
  /**
   * Shows the plugin UI window
   *
   * @param options - Optional configuration for the UI window dimensions
   */
  show(options?: ShowUIOptions): void;

  /**
   * Sets up a message handler to receive messages from the plugin UI.
   *
   * @param pluginMessage - The message data received from the UI
   */
  onMessage(pluginMessage: unknown): void;
  /**
   * Sends a message to the plugin UI
   *
   * @param pluginMessage - The message data to send to the UI
   */
  postMessage(pluginMessage: unknown): void;
}

/**
 * Represents a two-dimensional vector.
 *
 * @remarks
 * Used for positions, sizes, scales, and other two-dimensional values
 *
 * @example
 * ```ts
 * const position: Vector = { x: 100, y: 200 };
 * const scale: Vector = { x: 2, y: 2 };
 * ```
 *
 */
declare interface Vector {
  /**
   * X coordinate or horizontal component
   */
  x: number;
  /**
   * Y coordinate or vertical component
   */
  y: number;
}

/**
 * Options for creating a container with a shape.
 *
 */
declare type WithContainerOptions<T> = {
  /**
   * Initial position of the container
   */
  position?: Vector;
  /**
   * Options for the shape to create in the container
   */
  shape?: T;
};

/**
 * Helper type that extracts static values from Animatable properties.
 *
 * @remarks
 * Used when creating nodes to provide static initial values.
 *
 */
declare type WithStaticProps<T> =
  T extends Animatable<infer U>
    ? U
    : T extends Array<infer V>
      ? Array<WithStaticProps<V>>
      : T extends object
        ? {
            [K in keyof T]: WithStaticProps<T[K]>;
          }
        : T;