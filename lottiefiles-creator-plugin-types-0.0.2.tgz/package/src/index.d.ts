/// <reference path="./plugin-api-ref.d.ts" />

declare global {
  const creator: PluginAPI;
  const console: ConsoleAPI;
}

export {};