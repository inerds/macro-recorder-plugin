# @lottiefiles/creator-plugin-types

## 0.0.2

### Patch Changes

- 198c9a9: Add easing and data plugin apis

## 0.0.1

### Patch Changes

- 3b7875e: Publish initial version.
