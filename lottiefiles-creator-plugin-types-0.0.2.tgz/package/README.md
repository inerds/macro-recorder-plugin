# Creator Plugin API Types

TypeScript type definitions for the LottieFiles Creator Plugin API.

## Installation

```bash
pnpm install @lottiefiles/creator-plugin-types
```

## Usage

To make these type definitions globally available without needing imports, configure your `tsconfig.json`:

```json
{
  "compilerOptions": {
    "typeRoots": [
      "./node_modules/@types",
      "./node_modules/@lottiefiles/creator-plugin-types"
    ]
  }
}
```

Now you can use the plugin types without any import statements:

```typescript
// No imports needed!
creator.ui.show();
```
